#ifndef RODRIGUEZ_GERMAN_1G_H_INCLUDED
#define RODRIGUEZ_GERMAN_1G_H_INCLUDED
typedef struct
{
 int id;
 char nombre[51];
 char apellido[51];
 int numero;
 int isEmpty;

}Eabonado;


#endif // RODRIGUEZ_GERMAN_1G_H_INCLUDED

int menu();
int subMenu();
int subMenuModificar();
int inicializarAbonados(Eabonado list[], int len);
int buscarLibre(Eabonado list[], int len);
Eabonado agregarAbonado(Eabonado list[], int len, int id, char nombre[],char apellido[],int numero);
int buscarAbonadosxId(Eabonado list[], int len,int id);
int eliminarAbonado(Eabonado list[], int len, int id);
int mostrarAbonados(Eabonado list[], int length);
int cargarAbonado(Eabonado list[], int len, int id);
