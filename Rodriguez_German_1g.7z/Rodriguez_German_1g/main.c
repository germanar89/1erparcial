#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Rodriguez_German_1g.h"
#define TAME 5

int main()
{
    Eabonado list[TAME];
    int i;
    int id=1000;
    int idBusqueda;
    int indice;
    int sectorModificar;
    int idRemove;
    int flag=0;
    char nombreModificar[51];
    char ApellidoModificar[51];
    char salir = 'n';
    char salir2 = 'n';
    char salir3 ='n';
    char order[4];
    float salarioModificar;

    inicializarAbonados(list,TAME);

    do
    {

        switch(menu())//MENU PRINCIPAL
        {
        case 1:
            //SE CARGA UN EMPLEADO DATO A DATO
            cargarAbonado(list,TAME,id);
            id++;
            flag=1;
            break;

        case 2:

            //MUESTRO LOS EMPLEADOS CARGADOS PARA QUE ELIJAN EL ID A MODIFICAR
            if(flag)
            {
                mostrarAbonados(list,TAME);
                fflush(stdin);

                //SE TOMA EL ID A MODIFICAR
                printf("Ingrese ID a modificar\n");
                scanf("%d", &idBusqueda);

                //SE BUSCA EL ID Y SE DEVUELVE EL INDICE EN EL ARRAY
                indice =buscarAbonadosxId(list,TAME,idBusqueda);
                if (indice != -1)
                {


                    do
                    {
                        switch(subMenuModificar())//MENU MODIFICAR
                        {
                        case 1:
                            //CAMBIO EL NOMBRE
                            fflush(stdin);
                            printf("ingrese nuevo nombre: \n");
                            scanf("%s", nombreModificar);
                            strcpy(list[indice].nombre,nombreModificar);
                            break;

                        case 2:
                            //CAMBIO EL APELLIDO
                            fflush(stdin);
                            printf("ingrese nuevo Apellido: \n");
                            scanf("%s", ApellidoModificar);
                            strcpy(list[indice].apellido,ApellidoModificar);
                            break;


                        case 5:

                            //SALIR EL MANU ANTERIOR

                            fflush(stdin);
                            printf("desea salir? s/n ");
                            scanf("%c", &salir3);

                            break;
                        default:

                            printf("ingrese una opcion valida \n");


                        }
                    }
                    while(salir3 =='n');
                }
                else
                {
                    printf("El ID no existe \n\n");
                    system("pause");
                }
            }
            else
            {
                printf("Debe ingresar un dato primero \n\n");
                system("pause");
            }

            break;
        case 3:
            if(flag)
            {
                mostrarAbonados(list,TAME);
                fflush(stdin);
                printf("ingrese ID a remover\n");
                scanf("%d",&idRemove);
                eliminarAbonado(list,TAME,idRemove);
            }
            else
            {
                printf("Debe ingresar un dato primero \n\n");
                system("pause");
            }
            break;
        case 6:
            if (flag)
            {


                do
                {
                    switch (subMenu())//MENU DE INFORMES
                    {
                    case 1:
                        //SE MUESTRAN ORDENADOS LOS DATOS POR APELLIDO ALFABETICAMENTE SEGUN SE INDIQUE CON EL ORDEN UP/DOWN

                        printf("    informe 1");

                        break;

                    case 2:
                        printf("    informe 2");
                        break;

                    case 3:

                        printf("    informe 3");

                        break;
                    default:

                        printf("ingrese una opcion valida \n");
                        system("pause");
                    }

                }

                while(salir2 =='n');


            }
            else
            {
                printf("Debe ingresar un dato primero \n\n");
                system("pause");
            }
            break;
        case 5:
            fflush(stdin);
            printf("desea salir? s/n ");
            scanf("%c", &salir);
            break;
        default:

            printf("ingrese una opcion valida \n");


        }
    }
    while(salir =='n');

    return 0;
}
