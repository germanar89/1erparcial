#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "Rodriguez_German_1g.h"


int menu()
{
    system("cls");
    int opcion;

    printf("*** ABM ABONADOS ***\n\n");
    printf("1. ALTA ABONADO:\n");
    printf("2. MODIFICAR ABONADO:\n");
    printf("3. BAJA ABONADO:\n");
    printf("4. NUEVA LLAMADA:\n");
    printf("5. FIN LLAMADA:\n");
    printf("6. INFORMAR:\n");
    printf("7. Salir\n");

    scanf("%d",&opcion);

    return opcion;
}
int inicializarAbonados(Eabonado list[], int len)
{
    int i;
    for(i=0; i<len; i++)
    {
        list[i].isEmpty = 1;
    }
    return 0;
}

int buscarLibre(Eabonado list[], int len)

{
    int i=0;
    int indice;


    for(i=0; i<len; i++)
    {

        indice =-1;

        if (list[i].isEmpty==1)
        {
            indice = i;
            break;
        }
    }

    return indice;
}

Eabonado agregarAbonado(Eabonado list[], int len, int id, char nombre[],char apellido[],int numero)
{
    int indice;
    Eabonado nuevoAb;

    indice=buscarLibre(list,len);
    if (indice == -1)
    {
        printf("No hay registros disponibles para cargar el aboando \n");
    }
    else
    {


        nuevoAb.id = id;
        strcpy(nuevoAb.nombre,nombre);
        strcpy(nuevoAb.apellido,apellido);
        nuevoAb.numero =numero;

        nuevoAb.isEmpty = 0;

        ;
    }

    return nuevoAb;
}

int buscarAbonadosxId(Eabonado list[], int len,int id)
{
    int i;
    int indice = -1;


    for (i=0; i<len; i++)
    {
        if (list[i].id == id)
        {
            indice=i;
        }
    }

    return indice;
}
int eliminarAbonado(Eabonado list[], int len, int id)
{
    char opcion;
    int indice;

    indice=buscarAbonadosxId(list,len,id);


    printf("%5d %10s %10s  2%d\nDesea eliminarlo s/n\n",list[indice].id,list[indice].apellido,list[indice].nombre,list[indice].numero);
    fflush(stdin);
    scanf("%c",&opcion);
    if(indice!=-1 && opcion== 's')
    {
        list[indice].isEmpty=1;

        printf("baja exitosa\n");
        system("pause");

    }
    else
    {
        printf("baja no realizada\n");
        system("pause");
    }
    return -1;
}
int mostrarAbonados(Eabonado list[], int length)
{
    int i;
    system("cls");


    printf("\n");
    for (i=0; i< length; i++)
    {
        if (list[i].isEmpty==0)
        {


            printf("%5d %10s %10s  %2d \n\n",list[i].id,list[i].apellido,list[i].nombre,list[i].numero);
        }
    }
    return 0;
}


int cargarAbonado(Eabonado list[], int len, int id)
{
    system("cls");
    int exito = 0;
    char nombre[51];
    char apellido[51];
    int numero;
    int indice;

    indice=buscarLibre(list,len);

    if (indice == -1)
    {
        printf("No hay registros disponibles para cargar el abonado \n");
    }
    else
    {
        printf("Ingrese nombre: ");
        fflush(stdin);
        gets(nombre);

        printf("Ingrese apellido: ");
        fflush(stdin);
        gets(apellido);
        printf("Ingrese numero: ");
        scanf("%d", &numero);
        list[indice]=agregarAbonado(list,len,id,nombre,apellido,numero);
        exito = 1;
        printf("\nalta exitosa\n\n");
    }




    system("pause");

    return exito;
}

int subMenu()
{
    system("cls");
    int opcion;

    printf("*** INFORMES ***\n\n");
    printf("1. Listado de los empleados ordenados por Apellido y Sector.\n");
    printf("2. Total y promedio de los salarios _ empleados superan el salario promedio.\n");

    printf("3. Retroceder \n");

    scanf("%d",&opcion);

    return opcion;
}
int subMenuModificar()
{
    system("cls");
    int opcion;

    printf("*** MODIFICAR ***\n\n");
    printf("1. Modificar Nombre\n");
    printf("2. Modificar Apellido\n");

    printf("5. Salir\n");

    scanf("%d",&opcion);

    return opcion;
}
